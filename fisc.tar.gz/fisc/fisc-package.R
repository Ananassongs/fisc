#' @name fisc
#' @title Functional InterSpecies Comparison
#' @author Emeric Henrion, Anastasia Songeon, 2015-04-08
#' @description This package compares two files : a list of orthologs (DIOPT file) and a list of 
#'              biological and physico-chemical functions, and creates a file where orthologs 
#'              (with a good score) is associated to its function. 
#'  
NULL
