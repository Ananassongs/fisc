#' Import functional Classes
#' 
#' Import fonctional Classes file and rename it.
#'
#' @param path : absolute path of the file
#' @param character : character which separates columns data
#'
#' @return renamed fonctionnal classes table
#'
#' @examples
#' ImportFunctionalClasses("~/function.tab")
#' ImportFunctionalClasses("~/function.tab", ",")
#'
#' @export
ImportFonctionnalClasses <- function(path, character = "\t"){
  data <- read.table(path, sep = character, header = T)
  colnames(data) <- c("fonctionID", "OrgInput.BaseID")
  return(data)
}

#' Import DIOPT
#' 
#' Import DIOPT file and rename it.
#'
#' @param path : absolute path of the file
#' @param character : character which separates columns data
#'
#' @return renamed DIOPT table 
#'
#' @examples
#' ImportDiopt("~/orthologs1WXcgQ.tab")
#'
#' @export
ImportDiopt = function(path, character = "\t"){
  data = read.table(path, sep = character, header = T)
  
  colnames(data)=c("Search.Term", "OrgInput.GeneID", "OrgInput.BaseID",
                   "OrgInput.Symbol", "OrgOutput.GeneID", "OrgOutput.BaseID",
                   "OrgOutput.Symbol", "DIOPT.Score", "Weighted.Score",
                   "Prediction.Derived.from")
  return(data)
}

#' Import lexicon from WormBase
#' 
#' Import lexicon file and rename it
#'
#' @param path : absolute path of the file
#' @param character : character which separates columns data
#'
#' @return renamed lexicon table 
#'
#' @examples
#' ImportLexicon("~/genesworm.tab")
#' ImportLexicon("~/genesworm.tab", ",")
#'
#' @export
ImportLexicon <- function(path, character = "\t", numcol){
  data <- read.table(path, sep = character, header = T, 
                     colClasses = c(rep("character",2), 
                                    rep("NULL", numcol-2)), fill=TRUE)
  colnames(data) <- c("OrgBaseID","OrgInput.Symbol")
  return(data)
}

#' Import lexicon from FlyBase
#' 
#' Import lexicon file and rename it
#'
#' @param path : absolute path of the file
#' @param character : the character which separates columns data
#'
#' @return renamed lexicon table
#'
#' @examples
#' ImportLexiconFlybase("~/genesfly.tab")
#' ImportLexiconFlybase("~/genesfly.tab", ",")
#'
#' @export
ImportLexiconFlybase <- function(path){
  data <- read.table(path,header = T, colClasses = c(rep("character",2), 
                                                     rep("NULL", 2)), fill=TRUE)
  colnames(data) <- c("OrgBaseID","OrgInput.Symbol")
  return(data)
}