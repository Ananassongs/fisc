#' Orthologs parser
#' 
#' Parse DIOPT table by DIOPT.score, select lines with the max.score
#' and all other lines with a score between max.score and         
#' max.score-2
#'
#' @param table : DIOPT table
#'
#' @return parsed table by DIOPT.score
#'
#' @examples
#' ParseOrtho(table.diopt)
#'
#' @export
ParseOrtho <- function(table){
  # get min and max of DIOPT.score for every genes
  maxScore <- max(table$DIOPT.Score)
  Max <- maxScore[1]
  Min <- Max - 1
  # get every lines with DIOPT.score = Max
  Ortho1 <- table[table$DIOPT.Score == Max, ]
  
  # test if DIOPT.score of the line is != 1 and get the line if DIOPT.score = Min
  if (Min != 1 & (Min %in% table$DIOPT.Score)) {
    Ortho2 <- table[table$DIOPT.Score == Min, ]
    # combine lines with max.score and min.score 
    final <- rbind(Ortho1, Ortho2)
  } else {
    # if the Min =< 1 we get only the max.score
    final <- Ortho1
  }
  # just only get lines with DIOPT.score > 1 
  final <- final[ which(final$DIOPT.Score != 1), ]  
  return(final)
}


#' DIOPT file parser
#' 
#' Parse DIOPT table by OrgInput.BaseID (unique database Id of the input 
#' organism) and divide DIOPT table. ParseOrtho selects "good" lines
#' for every section. 
#'
#' @param table.diopt : DIOPT table
#'
#' @return parsed table by DIOPT.score
#'
#' @examples
#' ParseDiopt(table.diopt)
#'
#' @export
ParseDiopt <- function(table.diopt) {
  # get every OrgInput.BaseID (redundant)
  factor.OrgInput.BaseID <- factor(table.diopt$OrgInput.BaseID) 
  # get just one name for each OrgInput.BaseID (non redundant)
  name.OrgInput.BaseID <- levels(factor.OrgInput.BaseID)
  table.org.input <- table.diopt[table.diopt$OrgInput.BaseID == 
                                   name.OrgInput.BaseID[1], ]
  # for every OrgInput.BaseID we parse by DIOPT.score
  ortho.final <- ParseOrtho(table.org.input)
  for (name in name.OrgInput.BaseID[2:length(name.OrgInput.BaseID)]) {
    table <- table.diopt[table.diopt$OrgInput.BaseID == name, ]
    ortho <- ParseOrtho(table)
    ortho.final <- rbind(ortho.final,ortho)
  }
  # if the final table is empty we print a warning message 
  if (nrow(ortho.final) == 0){
    print("If diopt scores are not high enough, genes can not be considered 
          as homologous")
  }
  return(ortho.final)
}