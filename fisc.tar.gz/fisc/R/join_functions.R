#' Join Classes and Lexicon
#' 
#' Join imported Classes table and imported Lexicon table
#'  
#' @param table1 : Classes table
#' @param table2 : Lexicon table
#' @param name.col : name of common column in the two tables
#'
#' @return a table with the common column and all other columns 
#'
#' @examples
#' JoinClassesLexicon(table.classes, table.lexicon, "OrgBaseID")
#' JoinClassesLexicon(table.classes, table.lexicon, "OrgInput.BaseID")
#'
#' @export
JoinClassesLexicon <- function(table1, table2, name.col){
  colnames(table1) <- c("fonctionID", "OrgBaseID")
  data <- merge(table1, table2, by=name.col, all.table1=TRUE)
  return(data)
}

#' Join DIOPT and Classes
#' 
#' Join parsed Diopt table and functional classes table
#'  
#' @param table1 : parsed DIOPT table
#' @param table2 : Classes table
#' @param name.col : name of common column in the two tables
#'
#' @return a table with the common column and all other columns 
#'
#' @examples
#' JoinClassesDiopt(table.diopt2, table.classes, "OrgInput.SymbolID")
#' JoinClassesDiopt(table.diopt2, table.classes, "OrgInput.BaseID")
#'
#' @export
JoinClassesDiopt <- function(table1, table2, name.col){
  data <- merge(table1, table2, by=name.col, all.table1 = TRUE)
  return(data)
}