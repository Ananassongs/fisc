#' Script execution
#' 
#' Complete the full script with 2 (DIOPT and functional classes files) 
#' or 3 files (+ lexicon file from Wormbase) 
#' Lexicon is the list of all genes present in Wormbase (cf data repository)
#'  
#' @param path1 : absolute path of DIOPT file 
#' @param path2 : absolute path of functional classes file 
#' @param path3 : absolute path of lexicon file (optionnal)
#'
#' @return exported csv table with the DIOPT columns and the function column,    
#' each line has the good score and the function associated
#'
#' @examples
#' ScriptExecutionWorm("~/orthologs1WXcgQ.xls", "~/function.csv", "~/          
#' Celegensgenes.csv")
#'                                                  
#' ScriptExecutionWorm("~/orthologs1WXcgQ.xls", "~/function2.csv")
#'                                              
#' @export
ScriptExecutionWorm <- function(path1, path2, path3 = NULL) {
  if (is.null(path3)) {
    table.diopt <- ImportDiopt(path1)
    table.classes <- ImportFonctionnalClasses(path2)
    table.diopt2 <- ParseDiopt(table.diopt)    
    result <- JoinClassesDiopt(table.diopt2, table.classes, "OrgInput.BaseID") 
    resultat <- result[,c(1, 4, 6, 7, 8, 11)]  
  } else {
    table.diopt <- ImportDiopt(path1)
    table.classes <- ImportFonctionnalClasses(path2)
    table.lexicon <- ImportLexicon(path3,  ",", 3)
    table.classes.lexicon.join <- JoinClassesLexicon(table.classes, 
                                                     table.lexicon, "OrgBaseID")
    table.diopt2 <- ParseDiopt(table.diopt)    
    result <- JoinClassesDiopt(table.diopt2, table.classes.lexicon.join, "OrgInput.Symbol")
    resultat <- result[, c(1, 4, 6, 7, 8, 12)]    
  }
}

#' Script execution
#' 
#' Complete the full script with 2 (DIOPT and functional classes files) 
#' or 3 files (+ lexicon file from the Flybase)
#' Lexicon is the list of all genes present in Flybase (cf. data repository)
#'  
#' @param path1 : absolute path of DIOPT file 
#' @param path2 : absolute path of functional classes file 
#' @param path3 : absolute path of lexicon file (optionnal)
#'
#' @return exported csv table with the DIOPT columns and the function column,    
#' each line has the good score and the function associated
#'
#' @examples
#' ScriptExecutionFly("~/_tempfiles_orthologsZFyw2g.xls", "~/function.csv",  
#' "~/flygenes.csv")
#'                                                  
#' ScriptExecutionFly("~/_tempfiles_orthologsZFyw2g.xls", "~/                 
#' function2.csv")
#'                                              
#' @export
ScriptExecutionFly <- function(path1, path2, path3 = NULL) {
  if (is.null(path3)) {
    table.diopt <- ImportDiopt(path1)
    table.classes <- ImportFonctionnalClasses(path2)
    table.diopt2 <- ParseDiopt(table.diopt)    
    result <- JoinClassesDiopt(table.diopt2, table.classes, "OrgInput.BaseID") 
    resultat <- result[,c(1, 4, 6, 7, 8, 11)]  
  } else {
    table.diopt <- ImportDiopt(path1)
    table.classes <- ImportFonctionnalClasses(path2)
    table.lexicon <- ImportLexiconFlybase(path3)
    table.classes.lexicon.join <- JoinClassesLexicon(table.classes, 
                                                     table.lexicon, "OrgBaseID")
    table.diopt2 <- ParseDiopt(table.diopt)    
    result <- JoinClassesDiopt(table.diopt2, table.classes.lexicon.join, 
                               "OrgInput.Symbol")
    resultat <- result[, c(1, 4, 6, 7, 8, 12)]    
  }
}