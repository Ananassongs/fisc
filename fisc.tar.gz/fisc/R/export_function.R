#' Export file
#' 
#' Export a table on csv file extension 
#'  
#' @param data : a table
#' @param name : name of output file
#'
#' @return exported csv table
#'
#' @examples
#' ExportResult(table.final)
#' ExportResult(table.final, myresults.csv)
#'
#' @export
ExportResult <- function(data,name="fisc_outputfile.csv"){
  write.csv(data, file=name)
}