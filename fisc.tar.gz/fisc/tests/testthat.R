library(testthat)
library(fisc)

test_check("fisc")
