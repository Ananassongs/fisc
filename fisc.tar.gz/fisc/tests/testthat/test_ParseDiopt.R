library("fisc")

setwd(".")
table.diopt <- ImportDiopt("../../data/orthologs1WXcgQ.tab")

result <- ParseDiopt(table.diopt)

test_that("ParseDIOPT", {
  expect_equal(nrow(result),8)
  expect_equal(ncol(result),10)
  expect_equal(result[1,8],8)
  expect_match(result[1,2],"179424")
  expect_match(result[5,2],"181261")  
})