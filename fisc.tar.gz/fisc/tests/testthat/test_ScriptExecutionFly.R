library("fisc")

setwd(".")

result <- ScriptExecutionFly("../../data/orthologsZFyw2g.tab", "../../data/functionfly.tab", "../../data/lexiconflybase.tab")

test_that("ScriptExecutionFly", {
  expect_equal(nrow(result),51)
  expect_equal(ncol(result),6)
  expect_equal(result[1,5],6)
  expect_match(result[1,1],"Bx")
  expect_match(result[1,3],"6641")
  expect_match(result[1,6],"GTPase") 
})