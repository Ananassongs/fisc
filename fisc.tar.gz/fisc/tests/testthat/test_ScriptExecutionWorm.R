library("fisc")

setwd(".")

result <- ScriptExecutionWorm("../../data/orthologsvPQ3L4.tab", "../../data/functional_classes.tab", "../../data/geneIDs.tab")

test_that("ScriptExecutionWorm", {
  expect_equal(nrow(result),357)
  expect_equal(ncol(result),6)
  expect_equal(result[1,5],4)
  expect_match(result[1,1],"his-22")
  expect_match(result[1,3],"18730")
  expect_match(result[1,6],"x0010004") 
})