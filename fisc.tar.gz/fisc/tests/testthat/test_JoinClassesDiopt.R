library("fisc")

setwd(".")
table.diopt <- ImportDiopt("../../data/orthologs1WXcgQ.tab")

table.classes <- ImportFonctionnalClasses("../../data/function2.tab")

result <- JoinClassesDiopt(table.diopt, table.classes, "OrgInput.BaseID")

test_that("JoinClassesDiopt", {
  expect_equal(ncol(result),11)
  expect_equal(nrow(result),71)
  expect_equal(result[1,8],8)
  expect_match(result[1,2],"WBGene00000102")
  expect_match(result[29,2],"WBGene00000146")  
})
