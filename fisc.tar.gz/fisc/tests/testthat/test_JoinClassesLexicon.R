library("fisc")

setwd(".")
table.classes <- ImportFonctionnalClasses("../../data/function.tab")
table.lexicon <- ImportLexicon("../../data/genes.tab",numcol=3,character=",")

table.classes.lexicon.join <- JoinClassesLexicon(table.classes, 
                                                 table.lexicon, "OrgBaseID")

test_that("JoinClassesLexicon", {
  expect_equal(nrow(table.classes.lexicon.join),13)
  expect_equal(ncol(table.classes.lexicon.join),3)
  expect_match(table.classes.lexicon.join[1,2],"apoptosis")
  expect_match(table.classes.lexicon.join[3,3],"age-1")
  expect_match(table.classes.lexicon.join[5,2],"kinase") 
})
